#!/usr/bin/env python3
# ============================================================
# CANTORAL — Conversion d'un export JSON (WebMaster > Exporter)
# vers un script SQL d'import pour la base PostgreSQL créée
# par cantoral_schema.sql.
#
# Usage :
#   python import_json_to_sql.py cantoral-export.json > cantoral_data.sql
#
# Aucune dépendance externe : uniquement la bibliothèque
# standard Python (json). Fonctionne avec Python 3.7+.
#
# Le script NE SE CONNECTE PAS à une base de données : il
# génère un fichier .sql que vous relisez puis exécutez
# vous-même (ex. psql -U <user> -d <base> -f cantoral_data.sql),
# une fois cantoral_schema.sql déjà appliqué.
# ============================================================

import json
import sys
import datetime

DEFAULT_MENTIONS = {"CDO": "Récité", "NP": "Récité", "DOXO": "Simple"}


def sql_str(v):
    """Retourne un littéral SQL sûr : NULL ou 'texte échappé'."""
    if v is None:
        return "NULL"
    s = str(v).replace("'", "''")
    return f"'{s}'"


def sql_num(v):
    if v is None or v == "":
        return "NULL"
    try:
        return str(int(v))
    except (ValueError, TypeError):
        try:
            return str(float(v))
        except (ValueError, TypeError):
            return "NULL"


def sql_bool(v):
    return "true" if v else "false"


def sql_date(v):
    """Les dates de l'app sont déjà au format YYYY-MM-DD."""
    if not v:
        return "NULL"
    return sql_str(v)


def sql_json(v):
    if not v:
        v = {}
    return "%s::jsonb" % sql_str(json.dumps(v, ensure_ascii=False))


def resolve_clocher_id(lieu_raw, clochets):
    """Le champ 'lieu' est normalement déjà un id de clocher (ex. '1').
    Pour les anciens programmes créés avant la mise en place du menu
    déroulant, il pouvait s'agir d'un texte libre : on tente alors
    une correspondance par libellé, sinon on renvoie None."""
    if lieu_raw is None or lieu_raw == "":
        return None, None
    lieu_str = str(lieu_raw)
    if lieu_str in clochets:
        return lieu_str, None
    # tentative de correspondance par libellé (texte libre historique)
    norm = lieu_str.strip().lower()
    for cid, label in clochets.items():
        if str(label).strip().lower() == norm:
            return cid, None
    return None, lieu_str  # non résolu : on garde le texte d'origine en commentaire


def main():
    if len(sys.argv) < 2:
        print("Usage : python import_json_to_sql.py <export.json>", file=sys.stderr)
        sys.exit(1)

    with open(sys.argv[1], "r", encoding="utf-8") as f:
        db = json.load(f)

    out = []
    w = out.append

    w("-- ============================================================")
    w("-- CANTORAL — Import des données exportées le "
      f"{datetime.date.today().isoformat()}")
    w("-- Généré automatiquement par import_json_to_sql.py")
    w("-- À exécuter APRÈS cantoral_schema.sql")
    w("-- ============================================================")
    w("")
    w("BEGIN;")
    w("")

    unresolved_notes = []

    # ------------------------------------------------------------
    # Tables de référence : upsert pour refléter l'état réel actuel
    # (y compris les entrées ajoutées depuis l'IHM WebMaster)
    # ------------------------------------------------------------
    clochets = db.get("clochets", {}) or {}
    if clochets:
        w("-- Clochers (upsert : conserve les ids d'origine)")
        for cid, label in clochets.items():
            w(f"INSERT INTO clochers (id, nom) VALUES ({sql_num(cid)}, {sql_str(label)}) "
              f"ON CONFLICT (id) DO UPDATE SET nom = EXCLUDED.nom;")
        w("")

    def upsert_lookup(table, data, label_field="libelle"):
        if not data:
            return
        w(f"-- {table}")
        for code, label in data.items():
            w(f"INSERT INTO {table} (code, {label_field}) VALUES ({sql_str(code)}, {sql_str(label)}) "
              f"ON CONFLICT (code) DO UPDATE SET {label_field} = EXCLUDED.{label_field};")
        w("")

    upsert_lookup("type_chant", db.get("type_chant", {}))
    upsert_lookup("type_messe", db.get("type_messe", {}))
    upsert_lookup("ordinaire_messe", db.get("ordinaire_messe", {}))
    upsert_lookup("instruments", db.get("instruments", {}))

    # ------------------------------------------------------------
    # Animateurs
    # ------------------------------------------------------------
    animateurs = db.get("animateurs", []) or []
    if animateurs:
        w("-- Animateurs")
        for a in animateurs:
            w(
                "INSERT INTO animateurs (id, nom, prenom, clocher_id, date_arrivee, personnalise) "
                f"VALUES ({sql_num(a.get('id'))}, {sql_str(a.get('nom'))}, {sql_str(a.get('prenom'))}, "
                f"{sql_num(a.get('clochet'))}, {sql_date(a.get('date_arrivee'))}, {sql_json(a.get('custom'))}) "
                "ON CONFLICT (id) DO UPDATE SET nom = EXCLUDED.nom, prenom = EXCLUDED.prenom, "
                "clocher_id = EXCLUDED.clocher_id, date_arrivee = EXCLUDED.date_arrivee, "
                "personnalise = EXCLUDED.personnalise;"
            )
        w("")

    # ------------------------------------------------------------
    # Musiciens
    # ------------------------------------------------------------
    musiciens = db.get("musiciens", []) or []
    if musiciens:
        w("-- Musiciens")
        for m in musiciens:
            w(
                "INSERT INTO musiciens (id, nom, prenom, instrument, clocher_id, date_arrivee, personnalise) "
                f"VALUES ({sql_num(m.get('id'))}, {sql_str(m.get('nom'))}, {sql_str(m.get('prenom'))}, "
                f"{sql_str(m.get('instrument'))}, {sql_num(m.get('clochet'))}, "
                f"{sql_date(m.get('date_arrivee'))}, {sql_json(m.get('custom'))}) "
                "ON CONFLICT (id) DO UPDATE SET nom = EXCLUDED.nom, prenom = EXCLUDED.prenom, "
                "instrument = EXCLUDED.instrument, clocher_id = EXCLUDED.clocher_id, "
                "date_arrivee = EXCLUDED.date_arrivee, personnalise = EXCLUDED.personnalise;"
            )
        w("")

    # ------------------------------------------------------------
    # Chants + pistes audio
    # ------------------------------------------------------------
    chants = db.get("chants", []) or []
    if chants:
        w("-- Chants")
        for c in chants:
            w(
                "INSERT INTO chants (id, titre, reference1, reference2, texte, type_messe, type_chant, "
                "compositeur, harmonisation, partition, youtube, personnalise) VALUES ("
                f"{sql_num(c.get('id'))}, {sql_str(c.get('titre'))}, {sql_str(c.get('reference1'))}, "
                f"{sql_str(c.get('reference2'))}, {sql_str(c.get('texte'))}, {sql_str(c.get('type_messe'))}, "
                f"{sql_str(c.get('type_chant'))}, {sql_str(c.get('compositeur'))}, "
                f"{sql_str(c.get('harmonisation'))}, {sql_str(c.get('partition'))}, "
                f"{sql_str(c.get('youtube'))}, {sql_json(c.get('custom'))}) "
                "ON CONFLICT (id) DO UPDATE SET titre = EXCLUDED.titre, reference1 = EXCLUDED.reference1, "
                "reference2 = EXCLUDED.reference2, texte = EXCLUDED.texte, type_messe = EXCLUDED.type_messe, "
                "type_chant = EXCLUDED.type_chant, compositeur = EXCLUDED.compositeur, "
                "harmonisation = EXCLUDED.harmonisation, partition = EXCLUDED.partition, "
                "youtube = EXCLUDED.youtube, personnalise = EXCLUDED.personnalise;"
            )
        w("")
        w("-- Pistes audio des chants (on repart de zéro pour éviter les doublons)")
        chant_ids_with_audio = [c.get("id") for c in chants if c.get("audios")]
        if chant_ids_with_audio:
            ids_list = ", ".join(sql_num(i) for i in chant_ids_with_audio)
            w(f"DELETE FROM chant_audios WHERE chant_id IN ({ids_list});")
        for c in chants:
            for i, audio in enumerate(c.get("audios") or []):
                w(
                    "INSERT INTO chant_audios (chant_id, label, src, ordre) VALUES ("
                    f"{sql_num(c.get('id'))}, {sql_str(audio.get('label'))}, "
                    f"{sql_str(audio.get('src'))}, {i});"
                )
        w("")

    # ------------------------------------------------------------
    # Programmes + créneaux
    # ------------------------------------------------------------
    programmes = db.get("programmes", []) or []
    if programmes:
        w("-- Programmes")
        for p in programmes:
            clocher_id, unresolved = resolve_clocher_id(p.get("lieu"), clochets)
            if unresolved:
                unresolved_notes.append(
                    f"Programme #{p.get('id')} ({p.get('titre')}) : lieu texte libre "
                    f"non résolu = {unresolved!r} — à corriger manuellement (clocher_id laissé NULL)."
                )
            w(
                "INSERT INTO programmes (id, titre, date_messe, clocher_id, type_messe, ordinaire_messe, "
                "lecture, statut) VALUES ("
                f"{sql_num(p.get('id'))}, {sql_str(p.get('titre'))}, {sql_date(p.get('date'))}, "
                f"{sql_num(clocher_id)}, {sql_str(p.get('type_messe'))}, {sql_str(p.get('ordinaire_messe'))}, "
                f"{sql_str(p.get('lecture'))}, {sql_str(p.get('statut') or 'brouillon')}) "
                "ON CONFLICT (id) DO UPDATE SET titre = EXCLUDED.titre, date_messe = EXCLUDED.date_messe, "
                "clocher_id = EXCLUDED.clocher_id, type_messe = EXCLUDED.type_messe, "
                "ordinaire_messe = EXCLUDED.ordinaire_messe, lecture = EXCLUDED.lecture, "
                "statut = EXCLUDED.statut;"
            )
        w("")
        w("-- Créneaux des programmes (on repart de zéro pour éviter les doublons)")
        prog_ids = [p.get("id") for p in programmes]
        if prog_ids:
            ids_list = ", ".join(sql_num(i) for i in prog_ids)
            w(f"DELETE FROM programme_creneaux WHERE programme_id IN ({ids_list});")
        for p in programmes:
            slots = p.get("slots") or {}
            for code, val in slots.items():
                if val is None or val == "":
                    continue
                if val == "ORDINAIRE":
                    w(
                        "INSERT INTO programme_creneaux (programme_id, creneau, est_ordinaire) VALUES ("
                        f"{sql_num(p.get('id'))}, {sql_str(code)}, true);"
                    )
                elif val == "MENTION":
                    mention = DEFAULT_MENTIONS.get(code, "Récité")
                    w(
                        "INSERT INTO programme_creneaux (programme_id, creneau, mention) VALUES ("
                        f"{sql_num(p.get('id'))}, {sql_str(code)}, {sql_str(mention)});"
                    )
                else:
                    w(
                        "INSERT INTO programme_creneaux (programme_id, creneau, chant_id) VALUES ("
                        f"{sql_num(p.get('id'))}, {sql_str(code)}, {sql_num(val)});"
                    )
        w("")

    # ------------------------------------------------------------
    # Calendrier (offices)
    # ------------------------------------------------------------
    calendrier = db.get("calendrier", []) or []
    if calendrier:
        w("-- Offices (calendrier)")
        for o in calendrier:
            clocher_id, unresolved = resolve_clocher_id(o.get("lieu"), clochets)
            if unresolved:
                unresolved_notes.append(
                    f"Office #{o.get('id')} du {o.get('date')} : lieu texte libre "
                    f"non résolu = {unresolved!r} — à corriger manuellement (clocher_id laissé NULL)."
                )
            w(
                "INSERT INTO offices (id, date_office, horaire, clocher_id, evenement, organiste_id, "
                "chantre_id, programme_id, personnalise) VALUES ("
                f"{sql_num(o.get('id'))}, {sql_date(o.get('date'))}, {sql_str(o.get('horaire'))}, "
                f"{sql_num(clocher_id)}, {sql_str(o.get('evenement'))}, {sql_num(o.get('organiste'))}, "
                f"{sql_num(o.get('chantre'))}, {sql_num(o.get('programmeId'))}, {sql_json(o.get('custom'))}) "
                "ON CONFLICT (id) DO UPDATE SET date_office = EXCLUDED.date_office, "
                "horaire = EXCLUDED.horaire, clocher_id = EXCLUDED.clocher_id, "
                "evenement = EXCLUDED.evenement, organiste_id = EXCLUDED.organiste_id, "
                "chantre_id = EXCLUDED.chantre_id, programme_id = EXCLUDED.programme_id, "
                "personnalise = EXCLUDED.personnalise;"
            )
        w("")

    # ------------------------------------------------------------
    # Dates marquées "Pas d'office"
    # ------------------------------------------------------------
    no_office = db.get("noOffice", []) or []
    if no_office:
        w("-- Dates sans office")
        for n in no_office:
            clocher_id, unresolved = resolve_clocher_id(n.get("lieu"), clochets)
            if clocher_id:
                w(
                    "INSERT INTO dates_sans_office (date_concernee, clocher_id) VALUES ("
                    f"{sql_date(n.get('date'))}, {sql_num(clocher_id)}) ON CONFLICT DO NOTHING;"
                )
        w("")

    # ------------------------------------------------------------
    # Notifications (le programme est stocké par TITRE dans l'app,
    # pas par id : on tente une correspondance, sinon on laisse NULL)
    # ------------------------------------------------------------
    notifications = db.get("notifications", []) or []
    if notifications:
        w("-- Notifications (correspondance par titre, best-effort)")
        titre_to_id = {p.get("titre"): p.get("id") for p in programmes}
        for n in notifications:
            prog_id = titre_to_id.get(n.get("programme"))
            if prog_id is None:
                unresolved_notes.append(
                    f"Notification du {n.get('date')} : programme {n.get('programme')!r} "
                    "introuvable par titre — programme_id laissé NULL."
                )
            w(
                "INSERT INTO notifications (programme_id, envoye_le, nb_destinataires) VALUES ("
                f"{sql_num(prog_id)}, {sql_str(n.get('date'))}, {sql_num(n.get('count') or 0)});"
            )
        w("")

    # ------------------------------------------------------------
    # Champs personnalisés (structure WebMaster)
    # ------------------------------------------------------------
    schema = db.get("schema", {}) or {}
    if any(schema.values()):
        w("-- Champs personnalisés")
        w("DELETE FROM champs_personnalises;")
        for entite, fields in schema.items():
            for f in fields or []:
                w(
                    "INSERT INTO champs_personnalises (entite, cle, libelle, type_champ) VALUES ("
                    f"{sql_str(entite)}, {sql_str(f.get('key'))}, {sql_str(f.get('label'))}, "
                    f"{sql_str(f.get('type') or 'text')});"
                )
        w("")

    # ------------------------------------------------------------
    # Réajustement des séquences (puisqu'on a inséré des ids explicites)
    # ------------------------------------------------------------
    w("-- Réajustement des séquences auto-incrémentées")
    seq_tables = [
        ("clochers", "id"), ("animateurs", "id"), ("musiciens", "id"), ("chants", "id"),
        ("chant_audios", "id"), ("programmes", "id"), ("programme_creneaux", "id"),
        ("offices", "id"), ("dates_sans_office", "id"), ("notifications", "id"),
        ("champs_personnalises", "id"),
    ]
    for table, col in seq_tables:
        w(
            f"SELECT setval(pg_get_serial_sequence('{table}', '{col}'), "
            f"COALESCE((SELECT MAX({col}) FROM {table}), 1), "
            f"(SELECT MAX({col}) FROM {table}) IS NOT NULL);"
        )
    w("")
    w("COMMIT;")

    if unresolved_notes:
        w("")
        w("-- ============================================================")
        w("-- POINTS À VÉRIFIER MANUELLEMENT APRÈS IMPORT :")
        for note in unresolved_notes:
            w(f"--  - {note}")
        w("-- ============================================================")

    print("\n".join(out))

    print(
        f"-- {len(chants)} chants, {len(musiciens)} musiciens, {len(animateurs)} animateurs, "
        f"{len(programmes)} programmes, {len(calendrier)} offices, "
        f"{len(notifications)} notifications convertis.",
        file=sys.stderr,
    )
    if unresolved_notes:
        print(f"ATTENTION : {len(unresolved_notes)} point(s) à vérifier manuellement (voir la fin du fichier .sql généré).", file=sys.stderr)


if __name__ == "__main__":
    main()
